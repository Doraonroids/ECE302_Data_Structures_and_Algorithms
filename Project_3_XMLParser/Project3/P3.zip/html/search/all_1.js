var searchData=
[
  ['add',['add',['../class_bag.html#ad6e62d53e33ddb1cca7e56eda3a222a0',1,'Bag']]]
];
